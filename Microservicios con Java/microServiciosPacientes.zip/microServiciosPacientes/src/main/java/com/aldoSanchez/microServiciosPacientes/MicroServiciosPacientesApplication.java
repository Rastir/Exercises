package com.aldoSanchez.microServiciosPacientes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServiciosPacientesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServiciosPacientesApplication.class, args);
	}

}
