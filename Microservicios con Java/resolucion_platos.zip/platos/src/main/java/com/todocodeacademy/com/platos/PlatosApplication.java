package com.todocodeacademy.com.platos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlatosApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlatosApplication.class, args);
	}

}
