package com.aldosanchez.microServiciosTurnos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServiciosTurnosApplicationTests {

	@Test
	void contextLoads() {
	}

}
