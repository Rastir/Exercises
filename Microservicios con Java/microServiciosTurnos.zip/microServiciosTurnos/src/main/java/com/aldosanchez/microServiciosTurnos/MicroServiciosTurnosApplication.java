package com.aldosanchez.microServiciosTurnos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServiciosTurnosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServiciosTurnosApplication.class, args);
	}

}
