package com.todocodeacademy.hotelsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
