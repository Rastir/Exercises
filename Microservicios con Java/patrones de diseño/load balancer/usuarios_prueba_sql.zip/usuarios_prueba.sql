INSERT INTO user (user_id, cellphone, lastname, name)
VALUES
    (1, '123-456-7890', 'Smith', 'John'),
    (2, '987-654-3210', 'Johnson', 'Emily'),
    (3, '555-555-5555', 'Williams', 'Michael'),
    (4, '111-222-3333', 'Davis', 'Jessica'),
    (5, '444-444-4444', 'Brown', 'Christopher');