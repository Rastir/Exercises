package com.todocodeacademy.com.ingredientes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngredientesApplication {

	public static void main(String[] args) {
		SpringApplication.run(IngredientesApplication.class, args);
	}

}
