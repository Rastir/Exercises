package com.aldosanchez.microServiciosIngredientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServiciosIngredientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
