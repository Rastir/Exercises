package com.aldosanchez.microServiciosPlatos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServiciosPlatosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServiciosPlatosApplication.class, args);
	}

}
